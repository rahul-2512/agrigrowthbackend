const config = {
  DBURL:
    "mongodb+srv://agriGrowth:agriGrowth@cluster0.m0wq2.mongodb.net/myFirstDatabase?retryWrites=true&w=majority",
  JWT_SECRET_KEY: "6QmfwstcO2-l9gDg4EZlZs09Aahw-_ZkXOs6lObsWrY",
};
module.exports = config;

//jwt-Token: eyJhbGciOiJIUzI1NiJ9.eyJSb2xlIjoiVG9rZW4gT3duZXIiLCJJc3N1ZXIiOiJQYXJhZyBTYXhlbmEiLCJVc2VybmFtZSI6IkFncmlHcm93dGgiLCJleHAiOjE2MjM1ODY3MjEsImlhdCI6MTYyMzU4NjcyMX0.6QmfwstcO2-l9gDg4EZlZs09Aahw-_ZkXOs6lObsWrY
